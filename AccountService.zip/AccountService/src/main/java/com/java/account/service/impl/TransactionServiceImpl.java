package com.java.account.service.impl;

import org.springframework.stereotype.Service;

import com.java.account.service.TransactionService;
@Service
public class TransactionServiceImpl implements TransactionService {

}
