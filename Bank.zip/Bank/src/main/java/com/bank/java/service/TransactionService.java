package com.bank.java.service;

import java.time.LocalDateTime;
import java.util.List;

import com.bank.java.Dto.TransactionRequestDto;
import com.bank.java.Dto.TransactionResponseDto;
import com.bank.java.Dto.TransactionResponseProj;

public interface TransactionService {

	List<TransactionResponseDto> saveTransactions(TransactionRequestDto transactionRequestDto);

	List<TransactionResponseProj> getTransaction(String transactionNumber);

	List<TransactionResponseProj> getTransactions(Integer accountId);

	List<TransactionResponseProj> getTransactionsByDate(LocalDateTime fromDate, LocalDateTime toDate);

}
