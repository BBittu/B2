package com.bank.java.service;

import java.util.List;

import com.bank.java.Dto.AccountRequestDto;
import com.bank.java.Dto.AccountResponseDto;
import com.bank.java.Dto.AccountResponseProj;

public interface AccountService {

	void saveAccount(AccountRequestDto accountRequestDto);

	List<AccountResponseDto> getAccounts();

	List<AccountResponseProj> getAccountsByCustomer(Integer customerId);

}
