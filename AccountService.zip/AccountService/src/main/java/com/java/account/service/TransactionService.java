package com.java.account.service;

public interface TransactionService {

}
