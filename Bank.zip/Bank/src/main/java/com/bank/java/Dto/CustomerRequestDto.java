package com.bank.java.Dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class CustomerRequestDto {
	
	@NotEmpty(message="customer name cannot be empty")
	private String customerName;
	
	@NotEmpty(message="phone num cannot be empty")
	@Size(min=10,max=10,message="phone num should be 10 digits")
	private String phoneNo;
	
	@Email(message="email entered is wrong")
	private String emailId;
	
	@NotEmpty(message="citycannot be empty")
	private String city;
	
	@NotEmpty(message="state cannot be empty")
	private String state;

}
