package com.java.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.account.service.AccountService;

@RestController
public class AccountController {
	@Autowired
	AccountService accService;

	@PostMapping("/transaction/{userId}/{totalAmount}")
	public String transaction(@PathVariable Integer userId, @PathVariable float totalAmount) {
		boolean result = accService.transaction(userId, totalAmount);
		if (result == true) {
			return "Transaction Successfull";
		}
		return "Transaction Denied";
	}

}
