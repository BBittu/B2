package com.bank.java.service;

import java.util.List;

import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.Dto.CustomerResponseDto;
import com.bank.java.Dto.CustomerResponseProj;

public interface CustomerService {

	void saveCustomer(CustomerRequestDto customerRequestDto);

	List<CustomerResponseDto> getCustomers();

	void deleteCustomer(Integer customerId);

	List<CustomerResponseProj> getCustomerbyName(String customerName);

}
