package com.java.account.feign;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient("OrderService")
public interface OrderClient {
 
}
