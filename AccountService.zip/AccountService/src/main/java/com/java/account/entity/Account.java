package com.java.account.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Account {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer accountId;
	private Integer userId;
	private float walletBalance;

}
