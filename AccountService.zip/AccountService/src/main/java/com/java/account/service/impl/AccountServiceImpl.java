package com.java.account.service.impl;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.account.entity.Account;
import com.java.account.entity.Transaction;
import com.java.account.exception.AccountNotFoundException;
import com.java.account.exception.InsuficientBalence;
import com.java.account.repository.AccountRepository;
import com.java.account.repository.TransactionRepository;
import com.java.account.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountRepository accRepo;
	@Autowired
	TransactionRepository trnRepo;

	@Override
	public boolean transaction(Integer userId, float totalAmount) {
		Optional<Account> account = accRepo.findByUserId(userId);
		if(account.isEmpty()) {
			
			throw new AccountNotFoundException("Account Not Found");
		}
		else {
			float amount = account.get().getWalletBalance();
			if (totalAmount <= amount) {
				Account acc = new Account();
				float finalbalance = amount - totalAmount;

				acc.setWalletBalance(finalbalance);
				acc.setAccountId(account.get().getAccountId());
				acc.setUserId(account.get().getUserId());
				accRepo.save(acc);

				Transaction tx = new Transaction();
				tx.setAmount(totalAmount);
				tx.setOrderDate(LocalDateTime.now());
				tx.setUserId(account.get().getAccountId());
				trnRepo.save(tx);
				return true;
			} else {
				throw new InsuficientBalence("Balance Not Suficient");
			}
		}

	}
}
