package com.bank.java.Dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class TransactionResponseDto {
	private String transactionNumber;
	private Double amount;
	private Integer accountId;
	private LocalDateTime date;
	private String transactionType;

}
