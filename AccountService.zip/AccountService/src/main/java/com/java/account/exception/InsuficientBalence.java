package com.java.account.exception;

public class InsuficientBalence extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsuficientBalence(String message) {
		super(message);
	}

}
