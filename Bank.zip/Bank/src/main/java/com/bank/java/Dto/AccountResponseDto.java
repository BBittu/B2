package com.bank.java.Dto;

import lombok.Data;

@Data
public class AccountResponseDto {
	
	private Integer accountId;
	private Long accountNumber;
	private Double balance;
	private String accountType;
}
