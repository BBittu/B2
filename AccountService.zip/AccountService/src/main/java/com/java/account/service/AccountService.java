package com.java.account.service;

public interface AccountService {

	boolean transaction(Integer userId, float totalAmount);

}
